/*jshint globalstrict:true */
/*global angular:true */
'use strict';

angular.module('testappimport.directives', [])
    .directive('appVersion', ['version', function(version) {
        return function(scope, elm, attrs) {
            elm.text(version);
        };
    }]);