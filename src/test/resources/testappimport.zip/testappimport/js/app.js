/*jshint globalstrict:true */
/*global angular:true */
'use strict';

/* Application level module which depends on filters, controllers, and services */
angular.module('testappimport', [
    'testappimport.controllers', 
    'testappimport.filters', 
    'testappimport.services', 
    'testappimport.directives', 
    'evo'
    ]).config(['$routeProvider', function($routeProvider) {
        $routeProvider
            .when('/search', {
                templateUrl: '/testappimport/partials/search.html'
            })
            .when('/results', {
                templateUrl: '/testappimport/partials/results.html' 
            })
            .otherwise({
                redirectTo: '/search'
            });
  }]);