/*jshint globalstrict:true */
/*global angular:true */
'use strict';

angular.module('testappimport.services', [])
    .factory('foo', function($resource) {
        return {
            bar: $resource('/testappimport/{controller}/{action}', {}, {
                get: {method: 'GET'},
                put: {method: 'PUT'}
            })
        };
    });